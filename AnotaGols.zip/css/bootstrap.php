<?php ?>

<link rel="stylesheet" href="../libs/css/bootstrap/bootstrap.min.css">
<script src="../libs/js/bootstrap/bootstrap.min.js"></script>
