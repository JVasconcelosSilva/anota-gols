<header>
    <link rel="stylesheet" href="/libs/css/menu.css">
<div class="navbar">
    <h3>Anota Gols</h3>
</div>
</header>