<?php

class connection {

    public static function OpenCon() {
        $dbhost = "sql160.main-hosting.eu";
        $dbuser = "u203111846_null";
        $dbpass = "equipenull";
        $db = "u203111846_anota_gols";
        $conn = new mysqli($dbhost, $dbuser, $dbpass, $db);
        return $conn;
    }

    function CloseCon($conn){
        $conn->close();
    }

}
